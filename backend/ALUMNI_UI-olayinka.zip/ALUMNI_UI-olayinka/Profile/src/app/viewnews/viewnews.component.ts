import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewnews',
  templateUrl: './viewnews.component.html',
  styleUrls: ['./viewnews.component.css']
})
export class ViewnewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
