import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutsingle',
  templateUrl: './aboutsingle.component.html',
  styleUrls: ['./aboutsingle.component.css']
})
export class AboutsingleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
