import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmanagersvp',
  templateUrl: './adminmanagersvp.component.html',
  styleUrls: ['./adminmanagersvp.component.css']
})
export class AdminmanagersvpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
